<?php
    echo "The name you typed is: " . $_REQUEST['user'];
?>